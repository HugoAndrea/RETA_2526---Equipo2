/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario.dao;

/**
 * 
 * @author DAW104
 * 
 * 
 * listar todo();
 */
public class ArmarioDAO {
    
}
